
## ----preliminaries,echo=FALSE--------------------------------------------
options(width=80)


## ----echo=TRUE, eval=FALSE-----------------------------------------------
## dsIQ <- read.csv('C:/BGResearch/IQ.csv', header=TRUE)
## dsFertility <- read.csv('C:/BGResearch/Fertility.csv', header=TRUE)
## ds <- merge(dsIQ, dsFertility, by="C0000100")


