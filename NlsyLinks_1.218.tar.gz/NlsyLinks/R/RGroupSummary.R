#' @name RGroupSummary
#' @export
#' 
#' @title Calculates summary statistics for each \emph{R}elatedness Group in the sample.
#' 
#' @description Before and after running ACE Models, it is important to examine the characteristics of the different groups.  When the ACE is estimated with an SEM using multiple groups, it is even even more important.  Groups may contain too few subjects to have a well-behaved covariance matrix.  
#' 
#' If a group's covariance matrix is not Positive Definite (or it's misbehaving in some other way), it's typically recommended to exclude that group from the SEM. 
#' @usage RGroupSummary(ds, oName_1, oName_2, rName, determinantThreshold=1e-5)
#' 
#' @param ds The \code{data.frame} containing the following variables:
#' @param oName_1 The name of the outcome variable corresponding to the first subject in the pair.
#' @param oName_2 The name of the outcome variable corresponding to the first subject in the pair.
#' @param rName The name of the variable specifying the pair's \code{Relatedness} coefficient.
#' @param determinantThreshold The minimum value the covariance matrix's determinant (for the group) should exceed to be considered Positive Definite.
#' 
#' @details This function doesn't specific to an ACE model and groups defined by \code{R}.  It could be applied to any multiple-group SEM with two manifest/outcome variables.  In the future, we may generalize it beyond two manifest variables.
#' 
#' To get summary stats for the entire sample, create a dummy indicator variable that assigns everyone to the same group.  See the second example below.
#' 
#' The default determinantThreshold value is nonzero, in order to forgive slight numerical inaccuracies caused by fixed-precision arithmetic.
#' 
#' @return A \code{data.frame} with one row per group.  The \code{data.frame} contains the following variables:
#' \item{ R }{The group's \code{R} value.  Note the name of this variable can be changed by the user, by specifying a non-default value to the \code{rName} argument.}
#' \item{ Included }{Indicates if the group should be included in a multiple-group SEM.}
#' \item{ PairCount }{The number of pairs in the group with \emph{complete} data for \code{R} and the two outcome/manifest variables.}
#' \item{ O1Mean }{ The mean (of the outcome variable) among the group's first members, excluding the missing values. }
#' \item{ O2Mean }{ The mean (of the outcome variable) among the group's second members, excluding the missing values. }
#' \item{ O1Variance }{ The variance (of the outcome variable) among the group's first members. }
#' \item{ O2Variance }{ The variance (of the outcome variable) among the group's second members. }
#' \item{ O1O2Covariance }{ The covariance (of the outcome variable) across the group's first and second members.}
#' \item{ Correlation }{The correlation (of the outcome variable) across the group's first and second members.}
#' \item{ Determinant }{ The determinant of the group's covariance matrix.}
#' \item{ PosDefinite }{ Indicates if the group's covariance matrix is positive definite.}
#' 
#' @references Please see ZZZ (200?) for more information about SEM with multiple groups.
#' 
#' TODO: refs for determinant & positive definite.
#' 
#' @author Will Beasley and David Bard
#' 
#' @examples
#' library(NlsyLinks) #Load the package into the current R session.
#' dsLinks <- Links79PairExpanded  #Load the dataset from the NlsyLinks package.
#' dsLinks <- dsLinks[dsLinks$RelationshipPath=='Gen2Siblings', ]
#' oName_1 <- "MathStandardized_1" #Stands for Outcome1
#' oName_2 <- "MathStandardized_2" #Stands for Outcome2
#' dsGroupSummary <- RGroupSummary(dsLinks, oName_1, oName_2)
#' dsGroupSummary
#' 
#' #Should return: 
#' # R Included PairCount O1Variance O2Variance O1O2Covariance Correlation Determinant PosDefinite
#' # 1 0.250     TRUE      2719   169.1291   207.0233       40.66048   0.2172970    33360.38    TRUE
#' # 2 0.375     TRUE       141   167.9943   181.8788       40.67609   0.2327024    28900.07    TRUE
#' # 3 0.500     TRUE      5508   230.9663   233.3492      107.59822   0.4634764    42318.42    TRUE
#' # 4 0.750    FALSE         2   220.5000    18.0000       63.00000   1.0000000        0.00   FALSE
#' # 5 1.000     TRUE        22   319.1948   343.1169      277.58874   0.8387893    32465.62    TRUE
#' 
#' #To get summary stats for the whole sample, create one large inclusive group.
#' dsLinks$Dummy <- 1
#' (dsSampleSummary <- RGroupSummary(dsLinks, oName_1, oName_2, rName="Dummy"))
#'                      
#' #Should return:
#' # Dummy Included PairCount M1Variance M2Variance M1M2Covariance Correlation Determinant PosDefinite
#' #1    1     TRUE      8392    216.466   229.2988       90.90266   0.4080195     41372.1        TRUE
#' ###
#' ### ReadCsvNlsy79
#' ###
#' \dontrun{
#' filePathGen2 <- "./NlsyLinksStaging/Datasets/Gen2Birth.csv"
#' ds <- ReadCsvNlsy79Gen2(filePath=filePathGen2)
#' }
#' 
#' @keywords ACE 

RGroupSummary <-
function( ds, oName_1, oName_2, rName="R", determinantThreshold=1e-5) {
#     ds <- Links79PairExpanded #Start with the built-in data.frame in NlsyLinks
#     oName_1 <- "MathStandardized_1" #Stands for Manifest1
#     oName_2 <- "MathStandardized_2" #Stands for Manifest2
#   
#   ds <-dsFull
#   rName <- "RRR"
  
  #ds <- subset(ds, R==.75)
  rLevelsFirstPass <- sort(unique(ds[,rName])) #Enumerate the values of R existing in the current data.frame.
  #determinantThreshold <- 0 #The value the determinent should exceed to qualify as positive definite. TODO: Consider allowing the user to increase this value a little above zero, for extra stability.
#   determinantThreshold <- 1e-5 #The value the determinent should exceed to qualify as positive definite. TODO: Consider allowing the user to increase this value a little above zero, for extra stability.
  dsGroupSummary <- data.frame(
    R=rLevelsFirstPass, Included=F, PairCount=NA, O1Mean=NA, O2Mean=NA,
    O1Variance=NA, O2Variance=NA, O1O2Covariance=NA, Correlation=NA, 
    Determinant=NA, PosDefinite=FALSE)
    
  index <- VerifyColumnExists(dataFrame=dsGroupSummary, columnName="R")
  colnames(dsGroupSummary)[index] <- rName
  
  #The primary goal of this loop is to identify the R groups whose covariance matrix isn't positive definite.
  #TODO: Consider rewriting with plyr.  It's small, so there won't be a performance benefit.  It will add another dependency to the package.
  for( rLevel in rLevelsFirstPass ) {
    #print(rLevel)
    dsGroupSlice <- ds[!is.na(ds[,rName]) & ds[,rName]==rLevel & !is.na(ds[, oName_1]) & !is.na(ds[, oName_2]), c(oName_1, oName_2)]
    
    if( nrow(dsGroupSlice) > 0 ) {
      o1Mean <- mean(dsGroupSlice[, oName_1], na.rm=TRUE)
      o2Mean <- mean(dsGroupSlice[, oName_2], na.rm=TRUE)
      groupCovarianceMatrix <- cov(dsGroupSlice)#, use="complete.obs") 
      determinant <- det(groupCovarianceMatrix)
      isPositiveDefinite <- (determinant > determinantThreshold)
      correlation <- cor(dsGroupSlice[, oName_1], dsGroupSlice[, oName_2])
    }
    else {
      o1Mean <- NA
      o2Mean <- NA
      groupCovarianceMatrix <- matrix(NA, ncol=2, nrow=2)
      determinant <- NA
      isPositiveDefinite <- F
      correlation <- NA
    }
    
    dsGroupSummary[dsGroupSummary[,rName]==rLevel, c("PairCount", "O1Mean", "O2Mean", "O1Variance", "O2Variance", "O1O2Covariance", "Correlation", "Determinant", "PosDefinite")] <- c(
      nrow(dsGroupSlice),
      o1Mean,
      o2Mean,
      groupCovarianceMatrix[1, 1],
      groupCovarianceMatrix[2, 2],
      groupCovarianceMatrix[1, 2],
      correlation,
      determinant,
      isPositiveDefinite
      )    
    #dsGroupSummary[dsGroupSummary[,rName]==rLevel, "Included"] <- isPositiveDefinite  
  }
  dsGroupSummary$PosDefinite <- as.logical(dsGroupSummary$PosDefinite) #I do not know how this variable was ever coerced from logical to numeric.
  dsGroupSummary[, "Included"] <- dsGroupSummary$PosDefinite #Maybe later there will be another criterion to include/exclude a group.
  
  return( dsGroupSummary )
}
